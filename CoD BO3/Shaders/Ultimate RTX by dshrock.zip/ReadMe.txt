Drag these presets into your games main root directory located at C:\Program Files (x86)\Steam\steamapps\common\Call of Duty Black Ops III.

Then select which one you want to use in the dropdown menu at the top of the ReShade menu.